// But :
// Auteur : Brandon Cordeiro-Ouimet
// Date : 2020-10-29


#pragma once

// La liste des d�clarations des fonctions qui permettent de g�rer les menus et leur validation
void afficherMenu1(); // Fonction qui affiche le menu des formes
void afficherMenu2();// Fonction qui affiche le menu du remplissage
int validerEntier(int minimum, int maximum); // Fonction qui lit le choix de l'utilisateur et v�rifie (programme fait par karine moreau en class du cegep de st-jerome)
int validerMenu(int menu, int max);
int saisirEntier();
﻿#include "Menus1825966.h"
#include "Formes1825966.h"
#include <iostream>
#include <string>
#include <time.h>

using namespace std;



void afficherMenu1()
{

    setlocale(LC_ALL, "");


    // affiche le premier menu, interface dois être
    /*
     Choisissez la forme :
       1. Rectangle
       2. Triangle
       3. Carré
       4. Losange
       5. Quitter
     Votre choix →
     */


     // Déclarations des variables




    cout << "Choisissez la forme :" << endl;
    cout << " 1. Rectangle" << endl;
    cout << " 2. Triangle" << endl;
    cout << " 3. Carré" << endl;
    cout << " 4. Losange" << endl;
    cout << " 5. Quitter" << endl;
    cout << "Votre choix --> ";

}

void afficherMenu2()
{

    setlocale(LC_ALL, "");


    /*

    1. Forme pleine
    2. Forme vide
    3. Retour au menu précédent
    Votre Choix -->

    */





    cout << "1. Forme pleine" << endl;
    cout << "2. Forme vide" << endl;
    cout << "3. Retour au menu précédent" << endl;
    cout << "Votre Choix -->";




}

int validerEntier(int minimum, int maximum)
{


    // auteur : Karine Moreau, programme fait en class
    string clavier;
    int choix;
    char maxii = maximum;
    char minii = minimum;






    getline(cin, clavier, '\n');            // Permet de stocker les caractères dans la variable clavier 
                                            // et de nettoyer la mémoire du clavier
    // Autre problème : stoi plante le programme si la chaine de caractères ne contient pas des chiffres
    // comme premiers caractères ou si elle est vide

    // Tant que 1. clavier est vide (clavier.empty() ou clavier == "") OU
    //          2. clavier ne commence pas (at(0), front(), [0]) par un chiffre (valeur positive) OU  commence  par le signe - et n'est pas suivi d'un chiffre




    /*while (!(!clavier.empty() && ((clavier.front() >= '0' && clavier.front() <= '9')
            || (clavier.length() > 1 && clavier.front() == '-' && clavier.at(1) >= '0' && clavier.at(1) <= '9'))))*/


    while ((clavier.empty() || ((clavier.front() < minii || clavier.front() > maxii)
        && (clavier.length() <= 1 || clavier.front() != '-' || clavier.at(1) < minii || clavier.at(1) > maxii))))


    {
        cout << "Erreur : veuillez entrez un entier compris entre " << minii << " et " << maxii << endl; // ici cela marche pas, on peut ecrire des chiffres en haut du maximum sans probleme
        system("pause");
        system("cls");


        if (minii == '1' && maxii == '5') // aucune idée pourquoi quand j'utilise minimum et maximum la valeur écrite est de 49 - 53 pour le premier menu
                                            // et de 49 a 51 pour le deuxieme menu, malgré cela mon programme fait bien en sorte que les chiffre que
                                            // l'utilisateur doit écrire doit être compris entre 1 et 5 ou 1 et 3
                                            // j'ai aussi essayer de ne pas mettre les ' ' pour la valeur qui défini minimum et maximum, mon 
                                            // programme recoit belle est bien 1 et 5 quand je fait cout << minimum << endl << maximum ; et 1 et 3 pour
                                            // lautre mais mon programme ne marche pas et affiche toujours un erreur si je n'ai pas les ' '
        {
            afficherMenu1();
        }
        if (minii == '1' && maxii == '3')
        {
            afficherMenu2();
        }
        getline(cin, clavier);            // Permet de stocker les caractères dans la variable clavier 
    }
    choix = stoi(clavier); // pour convertir la chaine en entier
    return choix;

    // Il faut maintenant convertir la chaine en entier


    // Ici, si l'utilisateur tape une lettre, le cin >> la refuse et surtout laisse le caractère dans la mémoire du clavier
    // Il met 0 dans la variable int, même si ce n'est pas la bonne valeur
    // Et donc le programme part en boucle infinie car le deuxième cin >> récupère les caractères laissés 
    // dans la mémoire du clavier
    // Solution ==> lire tous les caractères tapés au clavier avec une chaine de caractères : string avec getline


}

int validerMenu(int menu, int max)
{
    // Declaration des variables

    int Choix = 0;

    // Menu 1
    char MIN1 = '1'; // Les choix doit etre compris etres MIN1 et MAX1 
    char MAX1 = '5';
    const int QUITTER = 5; // on fait un autre variable au cas ou que le dernier choix dans le futur ne soit pu le dernier chiffre


    // Menu 2
    char MIN2 = '1'; // Les choix doit etre compris etres MIN2 et MAX2
    char MAX2 = '3';
    const int RETOUR = 3; // on fait un autre variable au cas ou que le dernier choix dans le futur ne soit pu le dernier chiffre

    // Donnee qui doivent etre redonner a notre main
    int choixForme;
    int choixRemplissage;

    if (menu == 1 && max == QUITTER)
    {
        system("cls");



        afficherMenu1();



        choixForme = validerEntier(MIN1, MAX1);
        Choix = choixForme;



    }
    if (menu == 2 && max == RETOUR)
    {
        system("cls");

        afficherMenu2();



        choixRemplissage = validerEntier(MIN2, MAX2);
        Choix = choixRemplissage;



    }

    return Choix;
}

int saisirEntier() // code fait en classe, auteur Karine Moreau
{
    string clavier;

    getline(cin, clavier, '\n');            // Permet de stocker les caractères dans la variable clavier 
                                            // et de nettoyer la mémoire du clavier
    // Autre problème : stoi plante le programme si la chaine de caractères ne contient pas des chiffres
    // comme premiers caractères ou si elle est vide

    // Tant que 1. clavier est vide (clavier.empty() ou clavier == "") OU
    //          2. clavier ne commence pas (at(0), front(), [0]) par un chiffre (valeur positive) OU  commence  par le signe - et n'est pas suivi d'un chiffre




    /*while (!(!clavier.empty() && ((clavier.front() >= '0' && clavier.front() <= '9')
            || (clavier.length() > 1 && clavier.front() == '-' && clavier.at(1) >= '0' && clavier.at(1) <= '9'))))*/


    while ((clavier.empty() || ((clavier.front() < '0' || clavier.front() > '9')
        && (clavier.length() <= 1 || clavier.front() != '-' || clavier.at(1) < '0' || clavier.at(1) > '9'))))


    {

        cout << "Erreur : vous devez entrer un entier." << endl;
        cout << "Veuillez entrer un nombre entier : ";
        system("pause");

        getline(cin, clavier, '\n');            // Permet de stocker les caractères dans la variable clavier 
    }


    // Il faut maintenant convertir la chaine en entier
    return stoi(clavier);

    // Ici, si l'utilisateur tape une lettre, le cin >> la refuse et surtout laisse le caractère dans la mémoire du clavier
    // Il met 0 dans la variable int, même si ce n'est pas la bonne valeur
    // Et donc le programme part en boucle infinie car le deuxième cin >> récupère les caractères laissés 
    // dans la mémoire du clavier
    // Solution ==> lire tous les caractères tapés au clavier avec une chaine de caractères : string avec getline


}
// But : 
// Auteur : Brandon Cordeiro-Ouimet
// Date : 2020-10-29


#pragma once

void traiterCarre(int remplissage);
void dessinerCarre(int cote, int choixRemplissage);

void traiterRectangle(int choixRemplissage);
void dessinerRectangle(int hauteur, int base, int choixRemplissage);

void traiterTriangle(int choixRemplissage);

void dessinerTriangle1(int hauteur, int choixRemplissage);

void dessinerTriangle2(int hauteur, int choixRemplissage);

void dessinerTriangle3(int hauteur, int choixRemplissage);

void dessinerTriangle4(int hauteur, int choixRemplissage);

void traiterLosange(int choixRemplissage);
void dessinerLosange(int hauteur, int choixRemplissage);

int genererNombreAleatoire();
#include <iostream>		
#include <time.h>		
#include "Menus1825966.h"		
#include "Formes1825966.h"	
#include <string>

using namespace std;

void traiterCarre(int choixRemplissage)

{

	char hauteur;

	cout << "Indiquer la hauteur : ";

	hauteur = saisirEntier();




	dessinerCarre(hauteur, choixRemplissage);
}

void dessinerCarre(int hauteur, int choixRemplissage)
{



	if (choixRemplissage == 1)
	{
		cout << "Voici votre carre plein de " << hauteur << endl;
		for (int y = hauteur; y >= 1; y--) // si y = 10 la hauteur donc on va faire la boucle une fois et cela va donner 10 boucle de x
		{
			for (int x = 1; x <= hauteur; x++) // on fait la boucle 10 fois si la hauteur est de 10, ce qui va faire en sorte que l'on 
											   //va pouvoir faire cette boucle un total de 100 fois pour pouvoir dessiner le carre
			{
				if (x == hauteur || y == hauteur || x == 1 || y == 1)
				{
					cout << "*";
				}
				else
				{
					cout << "#";
				}

			}
			cout << endl;
		}

	}

	if (choixRemplissage == 2)
	{
		cout << "Voici votre carre vide de " << hauteur << endl;
		for (int y = hauteur; y >= 1; y--) // si y = 10 la hauteur donc on va faire la boucle une fois et cela va donner 10 boucle de x
		{
			for (int x = 1; x <= hauteur; x++) // on fait la boucle 10 fois si la hauteur est de 10, ce qui va faire en sorte que l'on 
											   //va pouvoir faire cette boucle un total de 100 fois pour pouvoir dessiner le carre
			{
				if (x == hauteur || y == hauteur || x == 1 || y == 1)
				{
					cout << "*";
				}
				else
				{
					cout << " ";

				}

			}
			cout << endl;
		}
	}
	system("pause");
}

void traiterRectangle(int choixRemplissage)
{
	{

		int hauteur;
		int base;

		cout << "Indiquer la hauteur : " << endl;
		hauteur = saisirEntier();

		cout << "Indiquer la base : ";
		base = saisirEntier();


		dessinerRectangle(hauteur, base, choixRemplissage);
	}
}

void dessinerRectangle(int hauteur, int base, int choixRemplissage)
{



	if (choixRemplissage == 1)
	{
		cout << "Voici votre rectangle plein de " << hauteur << endl;
		for (int y = hauteur; y >= 1; y--) // si y = 10 la hauteur donc on va faire la boucle une fois et cela va donner 10 boucle de x
		{
			for (int x = 1; x <= base; x++) // on fait la boucle 10 fois si la hauteur est de 10, ce qui va faire en sorte que l'on 
											   //va pouvoir faire cette boucle un total de 100 fois pour pouvoir dessiner le carre
			{
				if (x == base || y == hauteur || x == 1 || y == 1)
				{
					cout << "*";
				}
				else
				{
					cout << "#";
				}

			}
			cout << endl;
		}

	}

	if (choixRemplissage == 2)
	{
		cout << "Voici votre rectangle vide de " << hauteur << endl;
		for (int y = hauteur; y >= 1; y--) // si y = 10 la hauteur donc on va faire la boucle une fois et cela va donner 10 boucle de x
		{
			for (int x = 1; x <= base; x++) // on fait la boucle 10 fois si la hauteur est de 10, ce qui va faire en sorte que l'on 
											   //va pouvoir faire cette boucle un total de 100 fois pour pouvoir dessiner le carre
			{
				if (x == base || y == hauteur || x == 1 || y == 1)
				{
					cout << "*";
				}
				else
				{
					cout << " ";

				}

			}
			cout << endl;
		}
	}
	system("pause");
}

void traiterTriangle(int choixRemplissage)
{
	int hauteur;
	int retour;
	retour = genererNombreAleatoire(); // nombre al�atoire g�nerer pour pouvoir avoir 4 nombre diff�rent qui fait en sorte
									   //que l'on peut avoir un chiffre al�atoire pour le switch qui contient les 4 triangles

	cout << "Indiquer la hauteur : ";
	hauteur = saisirEntier();


	switch (retour)		// switch pour d�siner les 4 triangles dans un sens diff�rent
	{
	case 1:
		dessinerTriangle1(hauteur, choixRemplissage);
		break;
	case 2:
		dessinerTriangle2(hauteur, choixRemplissage);
		break;
	case 3:
		dessinerTriangle3(hauteur, choixRemplissage);
		break;
	case 4:
		dessinerTriangle4(hauteur, choixRemplissage);
		break;
	}


}

void dessinerTriangle1(int hauteur, int choixRemplissage)
{



	if (choixRemplissage == 1)// quand on veut que le triangle soit remplis
	{
		cout << "Voici votre triangle plein de " << hauteur << endl;
		for (int y = hauteur; y >= 1; y--) // si y = 10 la hauteur donc on va faire la boucle une fois et cela va donner 10 boucle de x
		{
			for (int x = 1; x <= y; x++) // on fait la boucle 10 fois si la hauteur est de 10, ce qui va faire en sorte que l'on 
											   //va pouvoir faire cette boucle un total de 100 fois pour pouvoir dessiner le carre
			{
				if (x == 1 || y == hauteur || x == y)
				{
					cout << "*";
				}
				else
				{
					cout << "#";
				}
			}
			cout << endl;
		}

	}

	if (choixRemplissage == 2)// quand on veut que le triangle soit vide
	{
		cout << "Voici votre triangle plein de " << hauteur << endl;
		for (int y = hauteur; y >= 1; y--) // si y = 10 la hauteur donc on va faire la boucle une fois et cela va donner 10 boucle de x
		{
			for (int x = 1; x <= hauteur; x++) // on fait la boucle 10 fois si la hauteur est de 10, ce qui va faire en sorte que l'on 
											   //va pouvoir faire cette boucle un total de 100 fois pour pouvoir dessiner le carre
			{
				if (x == 1 || y == hauteur || x == y)
				{
					cout << "*";
				}
				else
				{
					cout << " ";
				}

			}
			cout << endl;
		}

	}
	system("pause");
}

void dessinerTriangle2(int hauteur, int choixRemplissage)
{



	if (choixRemplissage == 1)// quand on veut que le triangle soit remplis
	{
		cout << "Voici votre triangle plein de " << hauteur << endl;
		for (int y = hauteur; y >= 0; y--) // si y = 10 la hauteur donc on va faire la boucle une fois et cela va donner 10 boucle de x
		{
			for (int x = hauteur - y + 1; x > 1; x--) // boucle sers a mettre les espaces devant le triangle pour pouvoir faire la pente dans le bon sens sans avoir de #

			{
				if (x == 2)
				{
					cout << '*';
				}
				else
				{
					cout << " ";
				}



			}
			for (int a = 0; a < y; a++)
			{
				if (y == 1 || y == y - 1 || y == hauteur || a == y || a == y - 1 || a == hauteur)
				{
					cout << "*";
				}
				else
				{
					cout << "#";
				}

			}
			cout << endl;
		}

	}



	if (choixRemplissage == 2)// quand on veut que le triangle soit vide
	{
		cout << "Voici votre triangle plein de " << hauteur << endl;
		for (int y = hauteur; y >= 0; y--) // si y = 10 la hauteur donc on va faire la boucle une fois et cela va donner 10 boucle de x
		{
			for (int x = hauteur - y + 1; x > 1; x--) // boucle sers a mettre les espaces devant le triangle pour pouvoir faire la pente dans le bon sens sans avoir de #

			{
				if (x == 2)
				{
					cout << '*';
				}
				else
				{
					cout << " ";
				}



			}
			for (int a = 0; a < y; a++)
			{
				if (y == 1 || y == y - 1 || y == hauteur || a == y || a == y - 1 || a == hauteur)
				{
					cout << "*";
				}
				else
				{
					cout << " ";
				}

			}
			cout << endl;
		}

	}
	system("pause");
}

void dessinerTriangle3(int hauteur, int choixRemplissage)
{
	if (choixRemplissage == 1)// quand on veut que le triangle soit remplis
	{
		cout << "Voici votre triangle plein de " << hauteur << endl;
		for (int y = hauteur; y >= 1; y--)
		{

			for (int a = y - 1; a >= 1; a--)
			{
				cout << " ";

				if (a == 1)
				{
					cout << '*';
				}
			}

			for (int x = hauteur - y + 1; x >= 1; x--)
			{
				if (y == 1 || x == 1)
				{
					cout << "*";
				}
				else
				{
					cout << "#";
				}
			}




			cout << endl;
		}
	}



	if (choixRemplissage == 2)// quand on veut que le triangle soit vide
	{
		cout << "Voici votre triangle vide de " << hauteur << endl;
		for (int y = hauteur; y >= 1; y--) // si y = 10 la hauteur donc on va faire la boucle une fois et cela va donner 10 boucle de x
		{
			for (int x = 1; x <= hauteur; x++) // on fait la boucle 10 fois si la hauteur est de 10, ce qui va faire en sorte que l'on 
											   //va pouvoir faire cette boucle un total de 100 fois pour pouvoir dessiner le triangle
			{
				if (x == hauteur || y == 1 || x == y)
				{
					cout << "*";
				}
				else
				{
					cout << " ";
				}

			}
			cout << endl;
		}

	}
	system("pause");
}

void dessinerTriangle4(int hauteur, int choixRemplissage)
{
	cout << "Voici un triangle plein de " << hauteur << endl;
	if (choixRemplissage == 1)//Option pleine
	{


		for (int y = 0; y <= hauteur; y++) //On donne une valeur de base � y, tant que y n'�gal pas total � un moment donn�, y augmente de 1 laissant place � la seconde boucle.
		{
			for (int x = y; x > 0; x--)
			{
				if (x == 1 || y == 1 || x == hauteur || y == hauteur || y == x)
				{
					cout << "*";
				}
				else
				{
					cout << "#";
				}
			}
			cout << endl;
		}



	}


	if (choixRemplissage == 2)//Option vide
	{
		for (int y = 0; y <= hauteur; y++) //On donne une valeur de base � y, tant que y n'�gal pas total � un moment donn�, y augmente de 1 laissant place � la seconde boucle.
		{
			for (int x = y; x > 0; x--)
			{
				if (x == 1 || y == 1 || x == hauteur || y == hauteur || y == x)
				{
					cout << "*";
				}
				else
				{
					cout << " ";
				}
			}
			cout << endl;
		}
	}
	system("pause");
}

void traiterLosange(int choixRemplissage) // marche pas, j'ai essayer de combiner les fonction utiliser pour les triangle pour faire le losange mais je n'ai pas r�ussi
{
	int hauteur;

	cout << "Indiquer la hauteur : ";
	hauteur = saisirEntier();
	while (hauteur % 2 == 0)
	{

		cout << "Erreur : veuillez saisir un nombre impair : ";
		hauteur = saisirEntier();


	}
	dessinerLosange(hauteur, choixRemplissage);

}

void dessinerLosange(int hauteur, int choixRemplissage)
{

	if (choixRemplissage == 1)
	{
		if (choixRemplissage == 1)//  en haut a droite premier 1/4 du losange
		{
			cout << "Voici votre triangle plein de " << hauteur << endl;
			for (int y = hauteur; y >= 1; y--)
			{

				for (int a = y - 1; a >= 1; a--)
				{
					cout << " ";

					if (a == 1)
					{
						cout << '*';
					}
				}

				for (int x = hauteur - y + 1; x >= 1; x--)
				{
					if (y == 1 || x == 1)
					{
						cout << "*";
					}
					else
					{
						cout << "#";
					}
				}

				if (choixRemplissage == 1)//Option pleine
				{


					for (int y = 0; y <= hauteur; y++) //On donne une valeur de base � y, tant que y n'�gal pas total � un moment donn�, y augmente de 1 laissant place � la seconde boucle.
					{
						for (int x = y; x > 0; x--)
						{
							if (x == 1 || y == 1 || x == hauteur || y == hauteur || y == x)
							{
								cout << "*";
							}
							else
							{
								cout << "#";
							}
						}


						cout << endl;
					}
				}
			}
		}
	}













	if (choixRemplissage == 2)
	{
		cout << "Voici votre carre vide de " << hauteur << endl;
		for (int y = hauteur; y >= 1; y--) // si y = 10 la hauteur donc on va faire la boucle une fois et cela va donner 10 boucle de x
		{
			for (int x = 1; x <= hauteur; x++) // on fait la boucle 10 fois si la hauteur est de 10, ce qui va faire en sorte que l'on 
											   //va pouvoir faire cette boucle un total de 100 fois pour pouvoir dessiner le carre
			{
				if (x == hauteur || y == hauteur || x == 1 || y == 1)
				{
					cout << "*";
				}
				else
				{
					cout << " ";

				}

			}
			cout << endl;
		}
	}
	system("pause");
}

int genererNombreAleatoire()
{

	// Code fait en classe
	const int MIN = 1;
	const int MAX = 4;
	int retour;





	// srand(time(NULL));   Il ne faut pas mettre la graine de l'al�a dans la fonction qui g�n�re le nombre
	// Le srand va uniquement au d�but du programme principal.
	retour = rand() % (MAX - MIN + 1) + (MIN);
	return retour;




}